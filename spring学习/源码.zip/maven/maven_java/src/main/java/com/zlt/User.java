package com.zlt;

public class User {
    private Integer uid;
    private String userName;
}
