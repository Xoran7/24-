package com.zlt;

import static org.junit.Assert.assertTrue;

import com.zlt.controller.AdminController;
import com.zlt.controller.UserController;
import com.zlt.entity.Clue;
import com.zlt.entity.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import java.io.InputStream;

/**
 * Unit test for simple App.
 */
public class AppTest

{
//    SqlSession sqlSession = null;
//
//    @Before
//    public void before(){
//        //构建mybatis的环境
//        InputStream resourceAsStream = AppTest.class.getClassLoader().getResourceAsStream("config.xml");
//        //构建会话工厂  可以理解为一个数据源
//        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
//        //得到会话  增删改不会自动提交事务，
//        sqlSession = sqlSessionFactory.openSession();
//
//    }
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        //登录的测试
       //创建容器对象
        ClassPathXmlApplicationContext beanFactory = new ClassPathXmlApplicationContext("ApplicationContext.xml");
       AdminController adminController = beanFactory.getBean("adminController", AdminController.class);
//       userController.update();
//       beanFactory.close();
        String account = "admin";
        String password = "2c3c10044e2a0c24723cd0327ad22079e5";
        adminController.login(account,password);
    }

    @Test
    public void regTest()
    {
        //登录的测试
        //创建容器对象
        ClassPathXmlApplicationContext beanFactory = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        UserController userController = beanFactory.getBean("userController", UserController.class);
        User user = new User();
        user.setId("5");
        user.setUserName("淡写 ╮青春");
        user.setState(1);
        user.setuState(2);
            userController.reg(user);
    }
    @Test
    public void InsertTest(){
        //创建容器对象
        ClassPathXmlApplicationContext beanFactory = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        UserController userController = beanFactory.getBean("userController", UserController.class);
        Clue clue = new Clue();
        clue.setId("1456151561sada");
        clue.setClueTitle("火影的不归之路");
        clue.setClueText("最后一代火影----森 究竟为何堕落？ 是人性的泯灭 还是道德的沦丧");
        userController.addClue(clue);
    }
}
