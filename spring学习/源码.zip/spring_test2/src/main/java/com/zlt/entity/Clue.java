package com.zlt.entity;

public class Clue {
    private String id;

    private String clueTitle;

    private String clueText;

    private String clueTime;

    private String uId;

    private String clueUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getClueTitle() {
        return clueTitle;
    }

    public void setClueTitle(String clueTitle) {
        this.clueTitle = clueTitle == null ? null : clueTitle.trim();
    }

    public String getClueText() {
        return clueText;
    }

    public void setClueText(String clueText) {
        this.clueText = clueText == null ? null : clueText.trim();
    }

    public String getClueTime() {
        return clueTime;
    }

    public void setClueTime(String clueTime) {
        this.clueTime = clueTime == null ? null : clueTime.trim();
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId == null ? null : uId.trim();
    }

    public String getClueUrl() {
        return clueUrl;
    }

    public void setClueUrl(String clueUrl) {
        this.clueUrl = clueUrl == null ? null : clueUrl.trim();
    }
}