package com.zlt.service.impl;

import com.zlt.entity.Admin;
import com.zlt.entity.AdminExample;
import com.zlt.mapper.AdminMapper;
import com.zlt.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminMapper adminMapper;
    @Override
    public Admin selectAdminByName(String account, String password) {
        AdminExample adminExample = new AdminExample();
        adminExample.createCriteria().andAccountEqualTo(account);
        List<Admin> admins = adminMapper.selectByExample(adminExample);
        //取出返回的 集合的第0位 判断是否为空 如果为空则根据用户名查询不到
        Admin admin = admins.get(0);
        if (admin!=null){
          //判断密码是否正确
        if (  admin.getPassword().equals(password)){
             return admin;
        }
        return  null;
      }
        return null;
    }
}
