package com.zlt.service;

import com.zlt.entity.Clue;
import com.zlt.entity.User;

public interface UserService {
    boolean update();

    boolean login();

    boolean reg(User user);

    boolean InsertClue(Clue clue);
}
