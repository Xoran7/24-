package com.zlt.service.impl;

import com.zlt.entity.Clue;
import com.zlt.entity.User;
import com.zlt.entity.UserExample;
import com.zlt.mapper.ClueMapper;
import com.zlt.mapper.UserMapper;
import com.zlt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service

public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ClueMapper clueMapper;
    @Override
//@Transactional()
    /**
     * transactionManager 和 value 是一样的 都是配置事务管理器
     * propagation 事务的传播机制  事务里面调事务 主要是业务层方法互相调用的时候事务的影响
     *     REQUIRED , 默认值 如果之前已经开启了事务，就直接使用之前的事务，如果之前没有开启事务，那么就开启一个事务
     *     SUPPORTS , 如果其他地方调用这个方法的时候，其他地方有事务就使用事务，否则这个方法就不使用事务
     *     MANDATORY , 必须在一个已有的事务中运行，否则会报错
     *     REQUIRES_NEW ,   不管之前是否开启了事务，都会创建一个新的事务，原本的事务挂起，直到这个方法执行完毕，原本的事务继续执行
     *     NOT_SUPPORTED , spring不会为他开启事务，相当于没有事务
     *     NEVER , 必须在一个没有的事务中运行，否则报错
     *     NESTED ; 如果当前存在事务，则开启嵌套事务在前台事务的内部运行，如果当前没有事务则和 REQUIRED 类似
     *     注意：
     *     REQUIRED  a 调用 b 如果两个方法都是 REQUIRED 一旦发生回滚两个方法都会回滚
     *     REQUIRES_NEW a 调用 b  如果b是REQUIRES_NEW 并且单独提交 a和b互不影响
     *     NESTED a 调用 b 如果a是 REQUIRED b是 NESTED b回滚 a不受影响  a回滚 b也会回滚
     * isolation 隔离级别  设置当前事务的隔离级别
     *      DEFAULT , 数据库是什么就是什么
     *     READ_UNCOMMITTED , 可读未提交
     *     READ_COMMITTED , 可读已提交
     *     REPEATABLE_READ , 可重复读
     *     SERIALIZABLE; 串行化
     * timeout 超时时间
     *
     *  readOnly 只读 如果设置为true 那么这个方法只能是查询 如果出现增删改都会报错
     *
     * rollbackFor 哪些会回滚  默认情况下只有运行时异常会回滚
     *
     * noRollbackFor 哪些不会回滚
     * @param username
     * @param password
     * @return
     */
    public boolean update() {
        User user = new User();
        user.setId("095098d8b4924ff7bacfeae6f2c85723");
        user.setUserName("王家森");
        user.setState(5);
//        user.setUserName("爱吃老麻抄手的森");
        userMapper.updateByPrimaryKey(user);
        System.out.println(1/0);
        User user1 = new User();
        user1.setId("0dc64b632b7d4667b38431c11aabb8ec");
        user1.setUserName("张文衔");
        user1.setState(15);
        userMapper.updateByPrimaryKey(user1);
        return true;
    }

    @Override
    public boolean login() {
        String userName = "张三123";
        String password = "2cbd4de76074e0f5b76ff89a091d90f6";
        //先通过username查询User对象
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(userExample);
        if (!users.get(0).getPassword().equals(password)) {
            throw new RuntimeException("账号错误");
        }
        //修改登录时间
        User user = users.get(0);
        user.setRegTime(String.valueOf(new Date()));
        userMapper.updateByPrimaryKey(user);

        return false;
    }

    @Override
    public boolean reg(User user) {
        //根据输入的用户名去查找 如果查询出来的集合为空则代表该账号没有被注册,那么就可以执行注册
        String userName = user.getUserName();
        UserExample userExample = new UserExample();
        userExample.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(userExample);

        boolean empty = users.isEmpty();
        if (empty==true){
            int insert = userMapper.insert(user);
            if (insert>0){
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean InsertClue(Clue clue) {
        int i = clueMapper.insert(clue);
        if (i>0){
            return true;
        }

        return false;
    }


}
