package com.zlt.controller;

import com.zlt.entity.Clue;
import com.zlt.entity.User;
import com.zlt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

@Controller//标记当前为控制层
public class UserController {
    @Autowired
    private UserService userService;
    public void update(){
       boolean success =  userService.update();
    }

    public void login(){
     boolean success=userService.login();
    }

    public void reg(User user){
        boolean reg = userService.reg(user);
        if (reg){
            System.out.println("注册成功");
        }else {
            System.out.println("注册失败");
        }
    }
    public void addClue(Clue clue){
        boolean success = userService.InsertClue(clue);
        if (success){
            System.out.println("添加成功");
        }else {
            System.out.println("添加失败");
        }
    }
}
