package com.zlt.controller;

import com.zlt.entity.Admin;
import com.zlt.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;

    public void login(String account,String password){
        Admin admin = adminService.selectAdminByName(account, password);
        if (admin!=null){
            System.out.println("登陆成功");
        }else {
            System.out.println("登录失败");
        }

    }
}
