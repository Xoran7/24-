package com.zlt.service;

import com.zlt.entity.Admin;

public interface AdminService {
    Admin selectAdminByName(String account,String password);

}
