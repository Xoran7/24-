package com.zlt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;

@RestController//标记当前为控制层
@SpringBootConfiguration

public class UserController {
    @Autowired
    private DataSource dataSource;


    @GetMapping("hello")
    public String helloWorld(){
        return "hello world";
    }


}
