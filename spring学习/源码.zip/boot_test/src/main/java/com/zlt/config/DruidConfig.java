package com.zlt.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.sql.DataSource;
//要求 从配置文件中读取driver url username password 的属性 赋值给下面四个字段 然后将 druidDataSource 注入到spring容器中
// 在controller中  dataSource中里面的url driver username 和password有值
@Configuration //当前为一个配置类
//@PropertySource("classpath:db.properties")
//@EnableConfigurationProperties(DruidProperties.class)
public class DruidConfig {
//   @Value("${jdbc.driver}")
//    private String driver;
//    @Value("${jdbc.url}")
//    private String url;
//    @Value("${jdbc.username}")
//    private String username;
//    @Value("${jdbc.password}")
//    private String password;
//    @Autowired
//    private DruidProperties druidProperties;
@Bean
@ConfigurationProperties(prefix ="jdbc")
    public DataSource dataSource(){
        DruidDataSource dataSource = new DruidDataSource();

//        dataSource.setDriverClassName(druidProperties.getDriverClassName());
//        dataSource.setUrl(druidProperties.getUrl());
//        dataSource.setUsername(druidProperties.getUsername());
//        dataSource.setPassword(druidProperties.getPassword());
        return  dataSource;

    }
}
