package com.zlt.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
@Data
//@ConfigurationProperties(prefix = "jdbc")//会自动读取application.yml文件 中的指定的前缀的配置
public class DruidProperties {

    private String driverClassName;

    private String url;

    private String username;

    private String password;
}
