package com.zlt.demo.controller;

import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("cookie")
public class CookieController {
    @GetMapping
    public void getCookie(@RequestParam("cookie")String cookie, @RequestHeader("User-Agent")String userAgent, HttpServletRequest request){
        String remoteAddr = request.getRemoteAddr();
        System.out.println("cookie："+cookie+"userAgent"+userAgent+"remoteAddr"+remoteAddr);
    }
}
