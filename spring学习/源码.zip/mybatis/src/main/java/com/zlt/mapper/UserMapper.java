package com.zlt.mapper;

import com.zlt.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserMapper {
    User selectUserByName(String user_name);
//  @Insert("insert into user( id,user_name,password,salt,state,u_state,o_id,user_phone,reg_time)\n" +
//          "values\n" +
//          "(#{id},#{user_name},#{password},#{salt},#{state},#{u_state},#{o_id},#{user_phone},#{reg_time})")
    int insert(User user);

    int update(User user);

    int delete(String id);
//    @Select("select * from user")
    List<User> selectAll();
    User selectUser(@Param("user_name") String user_name, @Param("password") String password);
    List<User> selectUser2(User user);

    int updateUser(User user);

    int insertUsers(@Param("users") List<User>users);

}
