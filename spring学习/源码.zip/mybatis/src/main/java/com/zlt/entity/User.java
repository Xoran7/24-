package com.zlt.entity;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {
    private String id;
    private String userName;
    private String password;
    private String salt;
    private Integer state;
    private Integer uState;
    private String oId;
    private String userPhone;
    private String regTime;
}