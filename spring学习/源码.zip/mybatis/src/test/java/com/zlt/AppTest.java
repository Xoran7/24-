package com.zlt;

import static org.junit.Assert.assertTrue;

import com.zlt.entity.User;
import com.zlt.mapper.UserMapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    private SqlSession sqlSession = null;


    @Before
    public void before(){
        //构建mybatis的环境
        InputStream resourceAsStream = AppTest.class.getClassLoader().getResourceAsStream("config.xml");
        //构建会话工厂  可以理解为一个数据源
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        //得到会话  增删改不会自动提交事务，
        sqlSession = sqlSessionFactory.openSession();

    }
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @Test
    public void select(){


        //执行查询
        Object user = sqlSession.selectOne("com.zlt.entity.User.selectUserByName", "金辉");
        System.out.println(user);
    }
    @Test
    public void insert(){
        User user = new User();
        user.setId("asdasdasdqwewqasfsad");
        user.setUserName("僧");
        user.setOId("12312421421");
        user.setSalt("asdq");
        user.setState(1);
        user.setUState(1);
        user.setRegTime("2024-04-01");
        int insert = sqlSession.insert("com.zlt.entity.User.insert", user);
        System.out.println(insert);
        //提交事务
        sqlSession.commit();
    }
    @Test
    public void update(){
        User user = new User();
        user.setId("123213213213");
        user.setUserName("成功的森");
        user.setPassword("123456");
        sqlSession.update("com.zlt.entity.User.update",user);
        sqlSession.commit();
    }
    @Test
    public  void delete (){
        sqlSession.delete("com.zlt.entity.User.delete","123213213213");
        sqlSession.commit();
    }
    @Test
    public void selectAll(){
        List<User> users = sqlSession.selectList("com.zlt.entity.User.selectAll");
        System.out.println(users);
    }

    @Test
    public void xml(){
        //条件查询
//        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//        User user = new User();
////        user.setUserName("王家僧");
////        user.setUserPhone("12315641561");
//        List<User> users = userMapper.selectUser2(user);
//        System.out.println(users);


        //注解实现insert
//        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//        User user = new User();
//        user.setId("asdasdasdsad");
//        user.setUser_name("爱吃老麻抄手的李陈");
//        user.setO_id("12312421421");
//        user.setSalt("asdq");
//        user.setState(1);
//        user.setU_state(1);
//        user.setReg_time("2024-04-01");
//        int insert = userMapper.insert(user);
//        System.out.println(insert);
//        sqlSession.commit();
        //动态sql 修改用户信息
//        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
//        User user = new User();
//        user.setId("123456");
//        user.setUserName("李陈");
//        user.setUserPhone("13666666666");
//        userMapper.updateUser(user);
//        sqlSession.commit();
        //批量新增
        User user = new User();
        user.setId("123124214211231231214214");
        user.setUserName("陈原1");
        user.setOId("12312421421");
        user.setSalt("asdq");
        user.setState(1);
        user.setUState(1);
        user.setRegTime("2024-04-01");
        User user1 = new User();
        user1.setId("fsdf213214sdfgsdeg");
        user1.setUserName("刘力旗");
        user1.setOId("12312421421");
        user1.setSalt("asdq");
        user1.setState(1);
        user1.setUState(1);
        user1.setRegTime("2024-04-01");
        List<User>users = new ArrayList<>();
        users.add(user);
        users.add(user1);
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        userMapper.insertUsers(users);
        sqlSession.commit();

    }
}
