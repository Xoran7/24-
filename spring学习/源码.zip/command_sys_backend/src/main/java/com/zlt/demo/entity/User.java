package com.zlt.demo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import lombok.*;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class User {
    private String id;
    private String userName;
    private String password;
    private String salt;
    private Integer state;
    @JsonProperty("uState")
    private Integer uState;
    @JsonProperty("oId")
    private String oId;
    private String userPhone;
    private String regTime;
}
