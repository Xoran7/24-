package com.zlt.demo.controller;

import com.zlt.demo.entity.Org;
import com.zlt.demo.service.OrgService;
import com.zlt.demo.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("org")
public class OrgController {
    @Autowired
    private OrgService orgService;
    /**
     * 查询组织
     * @return
     */

    @GetMapping("selectOrg")
    public ResponseEntity<Result>selectOrg(){
        List<Org> orgs = orgService.selectAllOrgs();
        return ResponseEntity.status(200).body(Result.ok("查询成功",orgs));
    }
}
