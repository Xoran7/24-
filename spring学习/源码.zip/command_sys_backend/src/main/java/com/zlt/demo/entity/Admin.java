package com.zlt.demo.entity;

import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Admin {

    private String id;
    private String account;
    private String regTime;
    private Integer state;
    private String password;
    private String salt;
}