package com.zlt.demo.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import springfox.documentation.annotations.ApiIgnore;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class AdminDto {

    private String id;
    private String account;
    private String regTime;
    private Integer state;
    private String password;
    private String salt;
    private String code;
}
