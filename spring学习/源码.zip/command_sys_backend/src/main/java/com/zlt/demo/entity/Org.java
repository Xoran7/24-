package com.zlt.demo.entity;

import lombok.*;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Org {

    private String id;
    private String orgName;
}
