package com.zlt.demo.service.impl;

import com.zlt.demo.entity.Clue;
import com.zlt.demo.entity.Notice;
import com.zlt.demo.entity.User;
import com.zlt.demo.mapper.UserMapper;
import com.zlt.demo.service.UserService;
import com.zlt.demo.utils.MD5Util;
import com.zlt.demo.utils.StringUtil;
import com.zlt.demo.vo.NoticeVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl  implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public boolean reg(User user) {
        //判断手机号有没有被注册
        String userPhone = user.getUserPhone();
        User user1 = userMapper.selectUserByPhone(userPhone);
        if (user1!=null){
            return false;
        }
        //根据手机号查询出来的user1为null，该手机号没有被注册
        User user2 = new User();
        user2.setUserName(user.getUserName());
        user2.setOId(user.getOId());
        user2.setUserPhone(user.getUserPhone());
        //获取盐值  （随机字符串）
        String salt = StringUtil.randomNumber(6);
        user2.setSalt(salt);
        //生成id 使用uuid
        String uuid = StringUtil.uuid();
        user2.setId(uuid);

        //用户输入的明文密码
        String password = user.getPassword();
        //对密码进行加密
        String newPassword = MD5Util.getMD5(password, salt, 10);
        user2.setPassword(newPassword);

        user2.setState(2);
        user2.setUState(0);

        String time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        user2.setRegTime(time);

        int i = userMapper.insertUser(user2);
        return i>0;


    }

    @Override
    public boolean login(User user) {
      //取出用户输入的手机号在数据库里面进行查询
        String userPhone = user.getUserPhone();
        User user1 = userMapper.selectUserByPhone(userPhone);
        //判断是否能查到输入手机号对应的数据
        if (user1==null){
            return false;
        }
        //判断是否通过审核
        if (user1.getState()==2){
            return false;
        }
        //判断是否封号

        if (user1.getState()==9){
            return false;
        }
        //将用户输入的密码进行加密
        String password = user.getPassword();
        //加密之后用户输入的密码
        String md5 = MD5Util.getMD5(password, user1.getSalt(), 10);
        if (!md5.equals(user1.getPassword())){
            return false;
        }

        return true;
    }

    @Override
    public List<NoticeVo> selectNotice() {
        List<NoticeVo> notices = userMapper.selectNotice();
        return notices;
    }

    @Override
    public boolean insertClue(Clue clue) {
        //时间和Id不是参数传过来的
        //生成id
        String uuid = StringUtil.uuid();
        clue.setId(uuid);
        //获取当前时间
        String time = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        clue.setClueTime(time);
        //调用mapper层
        int i = userMapper.insertClue(clue);
        return i>0;
    }

    @Override
    public List<Clue> selectClue(String uId) {
        List<Clue> clues = userMapper.selectClue(uId);
        return clues;
    }
}
