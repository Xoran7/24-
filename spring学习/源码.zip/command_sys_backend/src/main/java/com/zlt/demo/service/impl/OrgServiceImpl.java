package com.zlt.demo.service.impl;

import com.zlt.demo.entity.Org;
import com.zlt.demo.mapper.OrgMapper;
import com.zlt.demo.service.OrgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrgServiceImpl implements OrgService {
    @Autowired
    private OrgMapper orgMapper;
    @Override
    public List<Org> selectAllOrgs() {
        List<Org> orgs = orgMapper.selectAllOrgs();
        return orgs;
    }
}
