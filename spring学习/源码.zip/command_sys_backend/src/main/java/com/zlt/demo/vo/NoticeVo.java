package com.zlt.demo.vo;

import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NoticeVo {
    private String id;
    private String sysTitle;
    private String sysText;
    private String time;
    private String aId;
    private Integer state;
    private String account;
}
