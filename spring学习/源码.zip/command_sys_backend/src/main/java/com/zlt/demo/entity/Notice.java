package com.zlt.demo.entity;

import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Notice {
    private String id;
    private String sysTitle;
    private String sysText;
    private String time;
    private String aId;
    private Integer state;
}