package com.zlt.demo.service.impl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zlt.demo.entity.Admin;
import com.zlt.demo.entity.Org;
import com.zlt.demo.entity.User;
import com.zlt.demo.mapper.AdminMapper;
import com.zlt.demo.service.AdminService;
import com.zlt.demo.utils.MD5Util;
import com.zlt.demo.utils.StringUtil;
import com.zlt.demo.vo.UserVo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;
    @Override
    public boolean login(Admin admin) {
        String account = admin.getAccount();
        //根据账号从数据库中查询出来的 对象
        Admin admin1 = adminMapper.findAdminByAccount(account);
        if (admin1==null){
            return false;
        }
        //根据账号查出来的对象不为空
        //取出数据库里面对应的对象的盐值
        String salt = admin1.getSalt();
        //取出用户输入的密码
        String password = admin.getPassword();
        //对用户输入的密码进行加密
        String md5 = MD5Util.getMD5(password, salt, 10);
        //如果密码不等
        if (!admin1.getPassword().equals(md5)){
            return  false;
        }

        return true;
    }

    @Override
    public boolean updateOrg(Org org) {
        //判断id有没有值 如果有就是修改 如果没有就是新增
        String id = org.getId();
        if (id==null){
            String uuid = StringUtil.uuid();
            org.setId(uuid);
            int i = adminMapper.insertOrg(org);
            return i>0;
        }
        //新增
        int i = adminMapper.updateOrg(org);

        return i>0;
    }

    @Override
    public PageInfo<UserVo> selectUsers(Integer page, Integer limit, String userName, String userPhone, Integer state, String oId) {
        //开启分页
        PageHelper.startPage(page,limit);
        //查询数据
        List<UserVo> userVos = adminMapper.selectAll(userName,userPhone, state, oId);
        //将数据放入到pageInfo当中
        PageInfo<UserVo>pageInfo = new PageInfo<>(userVos);

        return pageInfo;
    }

    @Override
    public boolean updateUser(String uid) {
        String[] split = uid.split(",");
        //将数组转为集合
        List<String> list = Arrays.asList(split);
        int i = adminMapper.updateState(list);
        return i>0;
    }

    @Override
    public boolean updateUser1(String uid) {
        String[] split = uid.split(",");
        //将数组转为集合
        List<String> list = Arrays.asList(split);
        int i = adminMapper.updateState1(list);

        return i>0;
    }

    @Override
    public boolean updateOne(String uid) {
        int i = adminMapper.updateOne(uid);
        return i>0;
    }

    @Override
    public boolean updateDisable(String uid ,int state) {


            int i = adminMapper.updateState2(uid, state);
            return i>0;



    }

    @Override
    public boolean updateUserAll(User user) {
        int i = adminMapper.updateUser(user);
        return i>0;
    }

    @Override
    public boolean updatePassword(User user) {
        String salt = StringUtil.randomNumber(6);
        String md5 = MD5Util.getMD5(user.getPassword(), salt, 10);
        user.setSalt(salt);
        user.setPassword(md5);



        return adminMapper.updatePassword(user)>0;
    }
}
