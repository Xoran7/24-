package com.zlt.demo.mapper;

import com.zlt.demo.entity.Clue;
import com.zlt.demo.entity.Notice;
import com.zlt.demo.entity.User;
import com.zlt.demo.vo.NoticeVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserMapper {
    @Select("select * from user where user_phone = #{userPhone}")
    User selectUserByPhone(String userPhone);
    @Insert("insert into user (id,user_name,password,salt,state,u_state,o_id,user_phone,reg_time) values(#{id},#{userName},#{password},#{salt},#{state},#{uState},#{oId},#{userPhone},#{regTime})")
    int insertUser(User user);
    @Select("select a.account,n.* from notice n JOIN admin a on n.a_id=a.id where n.state = 0 order by n.time desc")
    List<NoticeVo>selectNotice();
    @Insert("insert into clue (id,clue_title,clue_text,clue_time,u_id,clue_url) values(#{id},#{clueTitle},#{clueText},#{clueTime},#{uId},#{clueUrl})")
    int insertClue(Clue clue);
    @Select("select * from clue where u_id=#{uId}")
     List<Clue>selectClue(String uId);
}
