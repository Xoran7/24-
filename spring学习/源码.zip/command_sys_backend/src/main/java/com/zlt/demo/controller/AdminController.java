package com.zlt.demo.controller;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import com.github.pagehelper.PageInfo;
import com.zlt.demo.dto.AdminDto;
import com.zlt.demo.entity.Admin;
import com.zlt.demo.entity.Org;
import com.zlt.demo.entity.User;
import com.zlt.demo.service.AdminService;
import com.zlt.demo.utils.StringUtil;
import com.zlt.demo.vo.Result;
import com.zlt.demo.vo.UserVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("admin")
public class AdminController {
    @Autowired
    AdminService adminService;
    @Autowired
    RedisTemplate redisTemplate;

    /**
     * 管理员登录
     *
     * @param
     * @return
     */


    @PostMapping("login")
    public ResponseEntity<Result> login(@RequestBody AdminDto adminDto, @RequestHeader("key") String key) {
        //取出验证码 正确的验证码
        String code = (String) redisTemplate.opsForValue().get(key);

        if (!adminDto.getCode().equals(code)) {
            return ResponseEntity.status(500).body(Result.error("验证码错误"));
        }
        Admin admin = new Admin();
        admin.setAccount(adminDto.getAccount());
        admin.setPassword(adminDto.getPassword());

        boolean login = adminService.login(admin);
        if (login) {
            return ResponseEntity.status(200).body(Result.ok("登录成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("登录失败"));
        }
    }

    /**
     * 获取验证码
     */
    @GetMapping("imageCode")
    public ResponseEntity<Result> imageCode() {
        //定义图形验证码的长款
        LineCaptcha lineCaptcha = CaptchaUtil.createLineCaptcha(120, 50, 4, 100);

        //验证码值
        String code = lineCaptcha.getCode();
        System.out.println(code);
        //保存下来存入redis里面,便于后面登录进行对比
        String key = StringUtil.uuid();
        System.out.println(key);
        redisTemplate.opsForValue().set(key, code);
        //将这个图片转换成base64字符串
        String imageBase64Data = lineCaptcha.getImageBase64Data();
        return ResponseEntity.status(200).header("key", key).body(Result.ok(code, imageBase64Data));


    }

    /**
     * 新增/修改组织
     */
    @PostMapping("updateOrg")
    public ResponseEntity<Result> updateOrg(@RequestBody Org org) {

        boolean success = adminService.updateOrg(org);
        if (success) {
            return ResponseEntity.status(200).body(Result.ok("操作成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("操作失败"));
        }


    }

    /**
     * 管理端组织调度页动态查询
     */
    @GetMapping("selectUser")
    public ResponseEntity<Result> selectUser(@RequestParam(required = false,defaultValue = "1")Integer page,@RequestParam(required = false,defaultValue = "10")Integer limit, String userName, String userPhone, Integer state, String oId) {

        PageInfo<UserVo> userVoPageInfo = adminService.selectUsers(page, limit, userName, userPhone, state, oId);

        return ResponseEntity.status(200).body(Result.ok("操作成功", userVoPageInfo));


    }

    /**
     * 批量审核
     */
    @GetMapping("updateUser")
    public ResponseEntity<Result> updateUser(String uid) {

        boolean success = adminService.updateUser(uid);
        if (success) {
            return ResponseEntity.status(200).body(Result.ok("操作成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("操作失败"));
        }


    }

    /**
     * 批量审核
     */
    @GetMapping("updateUser1")
    public ResponseEntity<Result> updateUser1(String uid) {

        boolean success = adminService.updateUser1(uid);
        if (success) {
            return ResponseEntity.status(200).body(Result.ok("操作成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("操作失败"));
        }


    }
    /**
     * 单个审核
     */
    @GetMapping("updateOne")
    public ResponseEntity<Result> updateone(String uid) {

        boolean success = adminService.updateOne(uid);
        if (success) {
            return ResponseEntity.status(200).body(Result.ok("操作成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("操作失败"));
        }


    }

    /**
     * 启用禁用
     */
@GetMapping("updateDisable")
public ResponseEntity<Result> updateDisable(String uid,int state) {

    boolean success = adminService.updateDisable(uid,state);
    if (success) {
        return ResponseEntity.status(200).body(Result.ok("操作成功"));
    } else {
        return ResponseEntity.status(500).body(Result.error("操作失败"));
    }


}
    /**
     * 编辑用户
     */
    @PostMapping("updateUserAll")
    public ResponseEntity<Result> updateUserAll(@RequestBody User user) {

        boolean success = adminService.updateUserAll(user);
        if (success) {
            return ResponseEntity.status(200).body(Result.ok("操作成功"));
        } else {
            return ResponseEntity.status(500).body(Result.error("操作失败"));
        }


    }


        /**
         * 管理端修改密码
         */
        @PostMapping("updatePassword")
        public ResponseEntity<Result> updatePassword (@RequestBody User user){

            boolean success = adminService.updatePassword(user);
            if (success) {
                return ResponseEntity.status(200).body(Result.ok("操作成功"));
            } else {
                return ResponseEntity.status(500).body(Result.error("操作失败"));
            }

        }
    }



