package com.zlt.demo.entity;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Clue {
    private String id;
    private String clueTitle;
    private String clueText;
    private String clueTime;
    @JsonProperty("uId")
    private String uId;
    private String clueUrl;
}