package com.zlt.demo.mapper;

import com.zlt.demo.entity.Org;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface OrgMapper {
    @Select("select * from org")
    List<Org> selectAllOrgs();
}
