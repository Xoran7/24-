package com.zlt.demo.controller;

import com.zlt.demo.entity.Clue;
import com.zlt.demo.entity.Notice;
import com.zlt.demo.entity.User;
import com.zlt.demo.service.UserService;
import com.zlt.demo.vo.NoticeVo;
import com.zlt.demo.vo.Result;

import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("user")
@Api(tags = "userController",description = "用户模块")//配置模块
public class UserController {
    @Autowired
    UserService userService;
    @PostMapping("reg")
    @ApiOperation("用户注册")
    @ApiResponses({
            @ApiResponse(code=0,message = "注册成功"),
            @ApiResponse(code=1,message = "注册失败")
    })
    public ResponseEntity<Result>reg(@RequestBody User user){
        boolean reg = userService.reg(user);
        if (reg){
            return ResponseEntity.status(200).body(Result.ok("注册成功"));
        }else {
            return ResponseEntity.status(500).body(Result.error("注册失败"));
        }
    }

    /**
     * 用户登录
     * @param user
     * @return
     */

    @PostMapping("login")

    public ResponseEntity<Result>login(@RequestBody User user){
        boolean login = userService.login(user);
        if (login){
            return ResponseEntity.status(200).body(Result.ok("登录成功"));
        }else {
            return ResponseEntity.status(500).body(Result.error("登录失败"));
        }
    }

    /**
     * 查询公告
     * @return
     */
    @GetMapping("selectNotice")
    public ResponseEntity<Result>selectNotice(){
        List<NoticeVo> notices = userService.selectNotice();
        return ResponseEntity.status(200).body(Result.ok("查询成功",notices));

    }

    /**
     * 用户端添加线索
     * @param clue
     * @return
     */
    @PostMapping("addClue")
    public ResponseEntity<Result>addClue(@RequestBody Clue clue){
        boolean add = userService.insertClue(clue);
        if (add){
            return ResponseEntity.status(200).body(Result.ok("添加成功"));
        }else {
            return ResponseEntity.status(500).body(Result.error("添加失败"));
        }
    }
    /**
     * 查询公告
     * @return
     */

    @GetMapping("selectClue")
    public ResponseEntity<Result>selectClue(String uId){
        List<Clue> clues = userService.selectClue(uId);
        return ResponseEntity.status(200).body(Result.ok("查询成功",clues));

    }

}
