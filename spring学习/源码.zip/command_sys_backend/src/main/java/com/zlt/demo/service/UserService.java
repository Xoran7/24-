package com.zlt.demo.service;

import com.zlt.demo.entity.Clue;
import com.zlt.demo.entity.Notice;
import com.zlt.demo.entity.User;
import com.zlt.demo.vo.NoticeVo;

import java.util.List;

public interface UserService {
    boolean reg(User user);

    boolean login(User user);

    List<NoticeVo> selectNotice();

    boolean insertClue(Clue clue);


    List<Clue>selectClue(String uId);
}
