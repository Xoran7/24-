package com.zlt.demo.mapper;

import com.zlt.demo.entity.Admin;
import com.zlt.demo.entity.Org;
import com.zlt.demo.entity.User;
import com.zlt.demo.vo.UserVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminMapper {
    @Select("select * from admin where account=#{account} and state = 0")
    Admin findAdminByAccount(String account);
    @Insert("Insert into org (id,org_name) values (#{id},#{orgName})")
    int insertOrg(Org org);

    @Update("update org set org_name = #{orgName} where id = #{id}")
    int updateOrg(Org org);
    @Select("<script>" +
            "select u.*,o.org_name from user u join  org o  on u.o_id=o.id "+
            "<where>"+
            "<if test = 'userName !=null'>"+
            "and user_name LIKE '%${userName}%'"+
            "</if>"+
            "<if test = 'userPhone !=null'>"+
            "and user_Phone LIKE '%${userPhone}%'"+
            "</if>"+
            "<if test = 'oId !=null'>"+
            "and o_id = #{oId}"+
            "</if>"+
            "<if test = 'state !=null'>"+
            "and state = #{state}"+
            "</if>"+
            "</where>"+
            "order by reg_time desc"+
            "</script>")
    List<UserVo>selectAll(@Param("userName") String username, @Param("userPhone") String userPhone, @Param("state") Integer state, @Param("oId") String oId);
      @Update("<script>update user set state =1 where id in<foreach collection ='uids' item='uid' separator=', ' open='(' close=')'>#{uid}</foreach></script>")
       int  updateState(@Param("uids") List<String>uids);

    @Update("<script>update user set state =9 where id in<foreach collection ='uids' item='uid' separator=', ' open='(' close=')'>#{uid}</foreach></script>")
    int  updateState1(@Param("uids") List<String>uids);

    @Update("update user set state =1 where id = #{uid}")
    int updateOne(String uid);
    @Select("select * from user where id = #{uid}")
    User selectUser(String uid);
    @Update("update user set state = #{state} where id = #{uid}")
    int updateState2(@Param("uid") String uid,@Param("state") int state);
    @Update("<script>" +
            "update user " +
            "<set>"+
            "<if test = 'userName !=null'>"+
             "user_name = #{userName},"+
            "</if>"+
            "<if test = 'userPhone !=null'>"+
            "user_phone = #{userPhone},"+
            "</if>"+
            "<if test = 'oId !=null'>"+
            "o_id = #{oId},"+
            "</if>"+
            "<if test = 'uState !=null'>"+
            "u_state = #{uState},"+
            "</if>"+
            "<if test = 'state !=null'>"+
            "state = #{state},"+
            "</if>"+
            "</set>"+
            "where id = #{id}"+
            "</script>")
    int updateUser(User user);
    @Update("update user set password=#{password},salt = #{salt} where id = #{id}")
    int updatePassword(User user);
}
