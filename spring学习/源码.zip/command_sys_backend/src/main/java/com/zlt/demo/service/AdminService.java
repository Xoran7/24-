package com.zlt.demo.service;

import com.github.pagehelper.PageInfo;
import com.zlt.demo.entity.Admin;
import com.zlt.demo.entity.Org;
import com.zlt.demo.entity.User;
import com.zlt.demo.vo.UserVo;

import java.util.List;

public interface AdminService {
    boolean login(Admin admin);

    boolean updateOrg(Org org);

    PageInfo<UserVo> selectUsers(Integer page, Integer limit, String userName, String userPhone, Integer state, String oId);

    boolean updateUser(String uid);

    boolean updateUser1(String uid);

    boolean updateOne(String uid);

    boolean updateDisable(String uid,int state);
    boolean updateUserAll(User user);

    boolean updatePassword(User user);
}
