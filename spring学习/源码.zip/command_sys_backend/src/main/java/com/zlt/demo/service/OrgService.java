package com.zlt.demo.service;

import com.zlt.demo.entity.Org;

import java.util.List;

public interface OrgService {
    List<Org> selectAllOrgs();
}
