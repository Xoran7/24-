package com.zlt.demo.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserVo {
    private String id;
    private String userName;
    private String password;
    private String salt;
    private  Integer state;
    private Integer uState;
    @JsonProperty("oId")
    private String oId;
    private  String userPhone;
    private String regTime;
    private String orgName;
}
