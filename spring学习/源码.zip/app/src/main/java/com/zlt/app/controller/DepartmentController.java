package com.zlt.app.controller;

import com.zlt.app.service.DepartmentService;
import com.zlt.app.vo.DepartmentVO;
import com.zlt.app.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("department")
public class DepartmentController {
    /**
     * 查询组织列表
     */
    @Autowired
    private DepartmentService departmentService;
    @GetMapping("selectDepartment")
    public Result<List<DepartmentVO>> department(){
        List<DepartmentVO> departmentVOS = departmentService.selectAll();
        return Result.success("查询成功",departmentVOS);
    }
}
