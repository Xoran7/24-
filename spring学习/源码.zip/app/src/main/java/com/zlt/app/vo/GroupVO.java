package com.zlt.app.vo;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class GroupVO {
    private Long gid;
    private String groupName;
    private String groupDesc;
    private UserVO creator;
    private Date createTime;
    private List<UserVO> groupMembers;
}
