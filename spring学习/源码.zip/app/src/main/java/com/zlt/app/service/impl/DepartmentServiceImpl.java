package com.zlt.app.service.impl;

import com.zlt.app.entity.Department;
import com.zlt.app.mapper.DepartmentMapper;
import com.zlt.app.service.DepartmentService;
import com.zlt.app.vo.DepartmentVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    private DepartmentMapper departmentMapper;
    @Override
    public List<DepartmentVO> selectAll() {
        List<DepartmentVO> departments = departmentMapper.selectAll();
        if(departments == null || departments.size() == 0){
            throw  new RuntimeException("当前没有组织数据");
        }
            return departments;
    }
}
