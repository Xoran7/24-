package com.zlt.app.service;

import com.zlt.app.dto.AddMemberDTO;
import com.zlt.app.dto.CreateGroupDTO;
import com.zlt.app.dto.NoExistMembersDTO;
import com.zlt.app.vo.GroupVO;
import com.zlt.app.vo.UserVO;

import java.util.List;

public interface GroupService {
    boolean createGroup(CreateGroupDTO createGroupDTO);

    List<GroupVO> selectMyGroup();
    List<UserVO> selectGroupMemeber(Long gid);

    boolean insertMember(AddMemberDTO addMemberDTO);


    List<UserVO> notExistMembers(NoExistMembersDTO noExistMembersDTO);
}
