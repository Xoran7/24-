package com.zlt.app.service;

import com.zlt.app.vo.DepartmentVO;

import java.util.List;

public interface DepartmentService {
    List<DepartmentVO> selectAll();
}
