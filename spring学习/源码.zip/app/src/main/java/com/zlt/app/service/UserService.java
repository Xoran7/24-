package com.zlt.app.service;

import com.zlt.app.dto.LoginDTO;
import com.zlt.app.dto.SearchUserDTO;
import com.zlt.app.dto.UserDTO;
import com.zlt.app.entity.User;
import com.zlt.app.vo.UserVO;

import java.util.List;

public interface UserService {
    boolean userReg(UserDTO userDTO);


    String userLogin(LoginDTO loginDTO);

    User checkToken(String token);

    User selectUserByTelPhone(String phone);

    List<UserVO> departmentUserList();
}
