package com.zlt.app.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LoginDTO {
    @NotNull(message = "请输入电话号码")
    private String phone;
    @NotNull(message = "密码不能为空")
    private String password;
}
