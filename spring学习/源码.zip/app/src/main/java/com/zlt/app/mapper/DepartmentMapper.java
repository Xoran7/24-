package com.zlt.app.mapper;

import com.zlt.app.entity.Department;
import com.zlt.app.vo.DepartmentVO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper

public interface DepartmentMapper {
    List<DepartmentVO> selectAll();
}
