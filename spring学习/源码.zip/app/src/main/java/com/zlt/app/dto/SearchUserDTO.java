package com.zlt.app.dto;

import lombok.Data;

@Data
public class SearchUserDTO {
    private String userName;
    private String phone;
}
