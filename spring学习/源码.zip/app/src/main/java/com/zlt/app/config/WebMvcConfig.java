package com.zlt.app.config;



import com.zlt.app.interceptor.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.context.annotation.Configuration;
//失效
//@Configuration
//public class WebMvcConfig implements WebMvcConfigurer {
//
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**").allowedHeaders("token")
//                .allowedOriginPatterns("*")
//                .allowedMethods("*")
//                .exposedHeaders("token");
//    }
//}
//使用新的全局跨域方式
@Configuration
public class WebMvcConfig implements WebMvcConfigurer{

    @Autowired
    private LoginInterceptor loginInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //配置拦截器
        registry.addInterceptor(loginInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/user/reg","/user/login","/user/send","/department/selectDepartment");
    }

    @Bean
    public CorsFilter corsFilter(){
        //添加CORS配置信息
        CorsConfiguration configuration = new CorsConfiguration();
        //放行哪些原始域
        configuration.addAllowedOrigin("*");
        //是否发送cookie
        configuration.setAllowCredentials(true);
        //放行哪些请求方式
        configuration.addAllowedMethod("*");
        //放行哪些原始请求头部信息
        configuration.addAllowedHeader("*");
        //暴露哪些头部信息
        configuration.addExposedHeader("*");
        //添加映射路径
        UrlBasedCorsConfigurationSource corsConfigurationSource = new UrlBasedCorsConfigurationSource();
        corsConfigurationSource.registerCorsConfiguration("/**",configuration);
        //返回新的CorsFilter
        return new CorsFilter(corsConfigurationSource);
    }
}
