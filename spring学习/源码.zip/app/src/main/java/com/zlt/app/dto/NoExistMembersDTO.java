package com.zlt.app.dto;

import lombok.Data;

@Data
public class NoExistMembersDTO {
    private Long gid;
    private Long did;
}
