package com.zlt.app.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class CreateGroupDTO {
    @NotNull(message = "必须有一个群成员")
    private List<Long> uids;
    @NotNull(message = "群名不能为空")
    private String groupName;
    private String groupDesc;
}
