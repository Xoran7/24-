package com.zlt.app.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Clue {

    private Long clueId;

    private String title;

    private String clueDesc;

    private String image;

    private Date createTime;

}
