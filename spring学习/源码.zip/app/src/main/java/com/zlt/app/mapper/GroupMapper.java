package com.zlt.app.mapper;

import com.zlt.app.entity.Group;
import com.zlt.app.entity.GroupMember;
import com.zlt.app.entity.User;
import com.zlt.app.vo.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GroupMapper {
    int insertGroup(Group group);

    int batchInsertGroupMember(List<GroupMember> groupMembers);

    List<Group> selectMyGroup(Long uid);

    User selectGroupCreator(Long gid);

    List<User> selectGroupMembers(Long gid);

    List<GroupMember> selectNotFirstJoinMembers(@Param("list") List<Long> uid, Long gid);

    int batchUpdateStatus(List<GroupMember> notFirstJoinMembers);

    List<Group> selectMyGroupAll(Long uid);

    List<User> notExistMembers(Long gid, Long did);
}
