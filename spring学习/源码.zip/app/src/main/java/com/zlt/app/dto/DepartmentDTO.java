package com.zlt.app.dto;

import lombok.Data;

@Data
public class DepartmentDTO {
    private Long did;
    private String departmentName;
    private String departmentDesc;
}
