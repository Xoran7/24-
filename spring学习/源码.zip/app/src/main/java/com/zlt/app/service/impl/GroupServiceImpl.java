package com.zlt.app.service.impl;

import com.zlt.app.dto.AddMemberDTO;
import com.zlt.app.dto.CreateGroupDTO;
import com.zlt.app.dto.NoExistMembersDTO;
import com.zlt.app.entity.Group;
import com.zlt.app.entity.GroupMember;
import com.zlt.app.entity.User;
import com.zlt.app.mapper.GroupMapper;
import com.zlt.app.service.GroupService;
import com.zlt.app.util.ActiveUserUtil;
import com.zlt.app.vo.GroupVO;
import com.zlt.app.vo.Result;
import com.zlt.app.vo.UserVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GroupServiceImpl implements GroupService {
    @Autowired
    private GroupMapper groupMapper;
    @Override
    public boolean createGroup(CreateGroupDTO createGroupDTO) {
        User user = ActiveUserUtil.getUser();
        //创建群
        Group group = new Group();
        group.setGroupName(createGroupDTO.getGroupName());
        group.setGroupDesc(createGroupDTO.getGroupDesc());
        group.setCreator(user.getUid());
        group.setCreateTime(new Date());
        int result = groupMapper.insertGroup(group);
        if(result < 1){
            throw new RuntimeException("创建群失败");
        }
        List<GroupMember> groupMembers = createGroupDTO.getUids().stream().map(uid -> {
            GroupMember groupMember = new GroupMember();
            groupMember.setGid(group.getGid());
            groupMember.setState("0");
            groupMember.setStatus("0");
            groupMember.setUid(uid);
            groupMember.setEnterTime(new Date());
            return groupMember;
        }).collect(Collectors.toList());
        if(groupMembers != null && groupMembers.size() >0){
            result = groupMapper.batchInsertGroupMember(groupMembers);
        }
        if(result < 1){
            throw new RuntimeException("成员加入失败");
        }
        else{
            return true;
        }
    }

    @Override
    public List<GroupVO> selectMyGroup() {
        //当前用户
        User user = ActiveUserUtil.getUser();
        List<Group> groups = groupMapper.selectMyGroup(user.getUid());
        if(groups == null || groups.isEmpty()){
            return null;
        }
        List<GroupVO> groupVOS = groups.stream().map(group -> {
            GroupVO groupVO = new GroupVO();
            BeanUtils.copyProperties(group,groupVO);
            //查一下创建者
            User creator = groupMapper.selectGroupCreator(group.getGid());
            UserVO userVO = new UserVO();
            BeanUtils.copyProperties(creator,userVO);
            groupVO.setCreator(userVO);
            //群成员
            List<UserVO> userVOS = selectGroupMemeber(group.getGid());
            groupVO.setGroupMembers(userVOS);
            return groupVO;
        }).collect(Collectors.toList());
        return groupVOS;
    }

    @Override
    public List<UserVO> selectGroupMemeber(Long gid) {
        List<User> groupMembers = groupMapper.selectGroupMembers(gid);
        List<UserVO> userVOS = groupMembers.stream().map(u -> {
            UserVO userVO = new UserVO();
            BeanUtils.copyProperties(u,userVO);
            return userVO;
        }).collect(Collectors.toList());
        return userVOS;
    }

    @Override
    public boolean insertMember(AddMemberDTO addMemberDTO) {
        List<GroupMember> groupMembers = addMemberDTO.getUids().stream().map(uid ->{
            GroupMember groupMember = new GroupMember();
            groupMember.setUid(uid);
            groupMember.setGid(addMemberDTO.getGid());
            groupMember.setEnterTime(new Date());
            groupMember.setState("0");
            groupMember.setStatus("0");
            return groupMember;
        }).collect(Collectors.toList());
        System.out.println(groupMembers);

        int result = groupMapper.batchInsertGroupMember(groupMembers);
        return  result>0;


//        List<GroupMember> notFirstJoinMembers = groupMapper.selectNotFirstJoinMembers(addMemberDTO.getUids(),addMemberDTO.getGid());
//
//        List<GroupMember> firstJoinMembers = new ArrayList<>();
//
//        for (GroupMember groupMember: groupMembers) {
//            int i = 0;
//            for(; i < notFirstJoinMembers.size(); i++){
//                if(groupMember.getUid().equals(notFirstJoinMembers.get(i).getUid())){
//                    break;
//                }
//            }
//            if(i >= notFirstJoinMembers.size()){
//                firstJoinMembers.add(groupMember);
//            }
//        }
//
//        int result = 0,i =0,i2 =0;
//        if(!notFirstJoinMembers.isEmpty()){
//            i = groupMapper.batchUpdateStatus(notFirstJoinMembers);
//        }
//        if(!firstJoinMembers.isEmpty()){
//            i2 = groupMapper.batchInsertGroupMember(firstJoinMembers);
//        }
//        result = i >0 || i2 > 0 ? 1 : 0;
//
//        return result>0;

    }

    @Override
    public List<UserVO> notExistMembers(NoExistMembersDTO noExistMembersDTO) {
        List<User> users = groupMapper.notExistMembers(noExistMembersDTO.getGid(),noExistMembersDTO.getDid());
        List<UserVO> userVOS = users.stream().map(u ->{
            UserVO userVO = new UserVO();
            BeanUtils.copyProperties(u,userVO);
            return userVO;
        }).collect(Collectors.toList());

        return userVOS;
    }


}
