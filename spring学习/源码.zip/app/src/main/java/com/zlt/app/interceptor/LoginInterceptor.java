package com.zlt.app.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zlt.app.entity.User;
import com.zlt.app.service.UserService;
import com.zlt.app.util.ActiveUserUtil;
import com.zlt.app.vo.Result;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;

    //请求到达目标资源之前执行，如果返回true则目标方法执行 如果返回false则请求被拦截不执行目标方法

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader("token");
        if(StringUtils.hasText(token)){
            try{
                //校验token
                User user =  userService.checkToken(token);
                //放进activeuser
                ActiveUserUtil.setUser(user);
                return true;
            }catch(RuntimeException e){
                response.setContentType("application/json;charset=utf-8");
                Result<Object> result = Result.builder().code(400).message(e.getMessage()).build();
                response.getWriter().write(new ObjectMapper().writeValueAsString(result));
                return false;
            }
        }
        else{
            response.setContentType("application/json;charset=utf-8");
            Result<Object> result = Result.builder().code(400).message("当前未登录").build();
            response.getWriter().write(new ObjectMapper().writeValueAsString(result));
            return false;
        }
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
    }
     //响应之后 保存的user删掉
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        ActiveUserUtil.remove();
    }
}
