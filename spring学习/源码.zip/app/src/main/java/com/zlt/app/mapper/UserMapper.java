package com.zlt.app.mapper;

import com.zlt.app.entity.User;
import com.zlt.app.vo.UserVO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
public interface UserMapper {
    User selectUserByPhone(String phone);

    int userReg(User user);

    List<UserVO> selectDepartmentUserList(Long did);
}
