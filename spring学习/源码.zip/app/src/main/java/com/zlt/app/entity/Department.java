package com.zlt.app.entity;

import lombok.Data;

@Data
public class Department {
    private Long did;
    private String departmentName;
    private String departmentDesc;
}
