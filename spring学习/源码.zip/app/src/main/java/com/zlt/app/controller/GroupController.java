package com.zlt.app.controller;

import com.zlt.app.dto.AddMemberDTO;
import com.zlt.app.dto.CreateGroupDTO;
import com.zlt.app.dto.NoExistMembersDTO;
import com.zlt.app.service.GroupService;
import com.zlt.app.vo.GroupVO;
import com.zlt.app.vo.Result;
import com.zlt.app.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("group")
public class GroupController {

    @Autowired
    private GroupService groupService;

    /**
     * 建群
     * @param createGroupDTO
     * @return
     */
    @PostMapping("creatGroup")
    public Result createGroup(@RequestBody @Validated CreateGroupDTO createGroupDTO){
       try {
           boolean success = groupService.createGroup(createGroupDTO);
           return success ? Result.success("创建群成功") : Result.fail("创建群失败");
       }catch (RuntimeException e){
           return Result.fail(e.getMessage());
       }
    }

    /**
     * 获取我的群列表
     * @return
     */
    @GetMapping("getmygroup")
    public Result getMyGroup(){
        List<GroupVO> groupVOS = groupService.selectMyGroup();
        return groupVOS == null ?Result.fail("当前用户没有群") : Result.success("查询成功",groupVOS);
    }



    /**
     * 邀请人进群
     */
    @PostMapping("insertMember")
    public Result insertMember(@RequestBody AddMemberDTO addMemberDTO){
        boolean success = groupService.insertMember(addMemberDTO);
        return success? Result.success("邀请成功") : Result.fail("邀请失败");
    }

    /**
     * 显示未加入的成员
     */
    @PostMapping("notExit")
    public Result notExistMembers(@RequestBody NoExistMembersDTO noExistMembersDTO){
        List<UserVO> groupMemberVOS = groupService.notExistMembers(noExistMembersDTO);
        return Result.success("查询成功",groupMemberVOS);
    }

}
