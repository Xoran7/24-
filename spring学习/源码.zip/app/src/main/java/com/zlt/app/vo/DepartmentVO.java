package com.zlt.app.vo;

import lombok.Data;

@Data
public class DepartmentVO {
    private Long did;
    private String departmentName;
    private String departmentDesc;
}
