package com.zlt.app.vo;

import lombok.Data;

@Data
public class UserVO {
    private Long uid;
    private String userName;
    private DepartmentVO department;
    private String phone;
    private String state;
    private Long did;
}
