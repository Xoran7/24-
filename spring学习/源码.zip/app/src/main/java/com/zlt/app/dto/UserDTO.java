package com.zlt.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserDTO {
    private Long uid;
    @NotBlank(message = "用户名不能为空")
    private String userName;
    @NotNull(message = "请选择组织")
    private Long did;
    @NotNull(message = "请输入电话号码")
    private String phone;
    @NotNull(message = "请输入验证码")
    private String code;
    @NotNull(message = "密码不能为空")
    private String password;
    private String salt;
    private String state;
}
