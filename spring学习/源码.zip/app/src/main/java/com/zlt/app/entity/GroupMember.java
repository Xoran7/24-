package com.zlt.app.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GroupMember {
    private Long mid;
    private Long gid;
    private Long uid;
    private Date enterTime;
    private String state;
    private String status;
}
