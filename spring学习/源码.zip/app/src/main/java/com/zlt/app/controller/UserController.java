package com.zlt.app.controller;

import com.zlt.app.dto.LoginDTO;
import com.zlt.app.dto.SMSDTO;
import com.zlt.app.dto.SearchUserDTO;
import com.zlt.app.dto.UserDTO;
import com.zlt.app.entity.User;
import com.zlt.app.service.DepartmentService;
import com.zlt.app.service.UserService;
import com.zlt.app.util.ActiveUserUtil;
import com.zlt.app.util.StringUtil;
import com.zlt.app.vo.DepartmentVO;
import com.zlt.app.vo.Result;
import com.zlt.app.vo.UserVO;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;


@RestController
@CrossOrigin
@RequestMapping("user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 获取短信验证码
     * @param
     * @return
     * @throws ExecutionException
     * @throws InterruptedException
     */
    @PostMapping("send")
    public ResponseEntity<Result> send(@RequestBody SMSDTO smsdto) throws ExecutionException,InterruptedException {
        //生成一个四位数的随机字符串
        String code = StringUtil.getRandomNumber(4);
        System.out.println(code);
        //生成一个redis里面的key
        String key = StringUtil.uuid()+smsdto.getPhone();
        System.out.println(key);
        redisTemplate.opsForValue().set(key, code, 5, TimeUnit.MINUTES);
        return ResponseEntity.status(200).header("SMS_SEND_",key).body(Result.success("发送成功"));

//        try {
//            SendSmsResponseBody sendSmsResponseBody = SMSUtil.sendSMS(smsdto.getPhone(), code);
//            if ("OK".equals(sendSmsResponseBody.getCode())) {
//                return ResponseEntity.status(200).header("key",key).body(Result.success("发送成功"));
//            } else {
//                return ResponseEntity.status(200).body(Result.fail("短信发送失败"));
//            }
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//            return ResponseEntity.status(200).body(Result.fail("短信发送失败"));
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//            return ResponseEntity.status(200).body(Result.fail("短信发送失败"));
//        }
    }

    /**
     * 注册
     * @param userDTO
     * @param key
     * @return
     */
    @PostMapping("reg")
    public ResponseEntity<Result> userReg(@RequestBody @Validated UserDTO userDTO,@RequestHeader("SMS_SEND_") String key){
        //验证码是否正确
        String code = (String) redisTemplate.opsForValue().get(key);
        if(code == null){
            return ResponseEntity.status(200).body(Result.fail("验证码过期"));
        }
        if(!code.equals(userDTO.getCode())){
            return ResponseEntity.status(200).body(Result.fail("验证码错误"));
        }
        boolean success = userService.userReg(userDTO);
        return success ? ResponseEntity.status(200).body(Result.success("注册成功")) : ResponseEntity.status(200).body(Result.fail("注册失败"));
    }

    /**
     * 登录
     * @param loginDTO
     * @return
     */

    @PostMapping("login")
    public ResponseEntity<Result> userLogin(@RequestBody @Validated LoginDTO loginDTO){
        try {
            String token = userService.userLogin(loginDTO);
            return ResponseEntity.status(200).header("token",token).body(Result.success("登录成功"));
        }catch (RuntimeException e){
            return ResponseEntity.status(200).body(Result.fail(e.getMessage()));
        }
    }

    /**
     * 获取用户信息
     * @return
     */
    @GetMapping("userinfo")
    public Result<UserVO> userInfo(){
        User user = ActiveUserUtil.getUser();
        UserVO userVO = new UserVO();
        System.out.println(user);
        BeanUtils.copyProperties(user,userVO);
        List<DepartmentVO> departmentVOList = departmentService.selectAll();
        Optional<DepartmentVO> first = departmentVOList.stream().filter(departmentVO -> departmentVO.getDid().equals(user.getDid())).findFirst();
        if((!first.isPresent())){
            return Result.fail("用户未登录");
        }
        userVO.setDepartment(first.get());
        return Result.success("获取用户数据成功",userVO);
    }

    /**
     * 部门列表
     * @return
     */

    @GetMapping("departmentuserlist")
    public Result<List<UserVO>> departmentUserList(){
        List<UserVO> userVOS = userService.departmentUserList();
        return Result.success("查询成功",userVOS);
    }


}
