package com.zlt.app.service.impl;

import com.zlt.app.dto.LoginDTO;
import com.zlt.app.dto.SearchUserDTO;
import com.zlt.app.dto.UserDTO;
import com.zlt.app.entity.User;
import com.zlt.app.mapper.UserMapper;
import com.zlt.app.service.UserService;
import com.zlt.app.util.ActiveUserUtil;
import com.zlt.app.util.JWTUtil;
import com.zlt.app.util.StringUtil;
import com.zlt.app.vo.DepartmentVO;
import com.zlt.app.vo.UserVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserService userService;

    @Autowired
    UserMapper userMapper;

    @Autowired
    RedisTemplate redisTemplate;

    @Override
    public boolean userReg(UserDTO userDTO) {

        //检查手机号是否注册
        User user  = userMapper.selectUserByPhone(userDTO.getPhone());
        if(user != null){
           throw new RuntimeException("手机号已经被注册");
        }
        user = new User();
        user.setUserName(userDTO.getUserName());
        user.setDid(userDTO.getDid());
        user.setPhone(userDTO.getPhone());
        user.setSalt(StringUtil.uuid());
        user.setPassword(StringUtil.md5Password(userDTO.getPassword(),user.getSalt(),10));
        user.setState("0");
        int result = userMapper.userReg(user);
        return result > 0;
    }

    @Override
    public String userLogin(LoginDTO loginDTO) {
        User user = userMapper.selectUserByPhone(loginDTO.getPhone());
        if(user == null){
            throw new RuntimeException("账号或密码错误");
        }
        String password = StringUtil.md5Password(loginDTO.getPassword(), user.getSalt(), 10);
        if(!password.equals(user.getPassword())){
            throw new RuntimeException("账号或密码错误");
        }
        //设置登录token
        String token = JWTUtil.sign(user.getPhone(), user.getPassword());
        redisTemplate.opsForValue().set("TOKEN_USER_" + token,user,12, TimeUnit.HOURS);
        return token;
    }

    @Override
    public User checkToken(String token) {
        //redis存活时间12小时 token是24小时
        User user = (User) redisTemplate.opsForValue().get("TOKEN_USER_" + token);
        if(user != null){
            return user;
        }

        String phone = JWTUtil.getPhone(token);
        if(!StringUtils.hasText(phone)){
            throw new RuntimeException("token不合法");
        }
        user = userMapper.selectUserByPhone(phone);
        if(user == null){
            throw new RuntimeException("token不合法");
        }
        if(!JWTUtil.verify(token,phone,user.getPassword())){
            throw new RuntimeException("token已过期，请重新登录");
        }
        redisTemplate.opsForValue().set("TOKEN_USER_" + token,user,12,TimeUnit.HOURS);
        return user;
    }

    @Override
    public User selectUserByTelPhone(String phone) {
        return userMapper.selectUserByPhone(phone);
    }

    @Override
    public List<UserVO> departmentUserList() {
        User user = ActiveUserUtil.getUser();
        List<UserVO> userVOS = userMapper.selectDepartmentUserList(user.getDid());

        return userVOS;
    }


}
