package com.zlt.boot;

import com.zlt.boot.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Date;

@SpringBootTest
class BootApplicationTests {
    @Autowired
    private RedisTemplate redisTemplate;

    @Test
    void contextLoads() {
        User user = new User(1l,18,"李陈","123456","chen",new Date());
        redisTemplate.opsForValue().set("user",user);

        Object user1 = redisTemplate.opsForValue().get("user");
        System.out.println(user1);
    }

}
