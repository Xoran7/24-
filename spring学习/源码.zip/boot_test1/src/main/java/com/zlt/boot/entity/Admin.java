package com.zlt.boot.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
public class Admin {
    private String id;
    private String account;
    private String regTime;
    private Integer state;
    private String password;
    private String salt;
}
