package com.zlt.boot.service;

import com.zlt.boot.entity.Admin;

public interface AdminService {
    Admin selectAdmin(String id);
}
