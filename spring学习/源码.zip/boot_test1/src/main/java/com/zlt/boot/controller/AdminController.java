package com.zlt.boot.controller;

import com.zlt.boot.entity.Admin;
import com.zlt.boot.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
    @Autowired
    AdminService adminService;
    @GetMapping("admin")
    public Admin selectAdmin(String id){
        Admin admin = adminService.selectAdmin(id);
        return admin;
    }
}
