package com.zlt.boot.service;

import com.zlt.boot.entity.User;

public interface UserService {
    User userInfo(Long id);
}
