package com.zlt.boot.mapper;

import com.zlt.boot.entity.Admin;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminMapper {
    @Select("select * from admin where id = #{id}")
    Admin selectAdmin(String id);
}
