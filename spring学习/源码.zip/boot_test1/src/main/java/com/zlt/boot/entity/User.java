package com.zlt.boot.entity;

import lombok.*;

import java.util.Date;
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User {
    private Long id;
    private Integer age;
    private String username;
    private String nickname;
    private String password;
    private Date birthday;
}
