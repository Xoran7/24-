package com.zlt.boot.service.impl;

import com.zlt.boot.entity.User;
import com.zlt.boot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import sun.dc.pr.PRError;

import java.util.Date;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private RedisTemplate redisTemplate;
    @Override
    @Cacheable(value = "zltRedis" ,keyGenerator = "keyGenerator")
    public User userInfo(Long id) {


        System.out.println("service执行");
        User user= new User(1L,18,"lichen","chen","123456",new Date());

        return user;
    }
}
