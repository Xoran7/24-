package com.zlt.boot.service.impl;

import com.zlt.boot.entity.Admin;
import com.zlt.boot.mapper.AdminMapper;
import com.zlt.boot.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl  implements AdminService {
    @Autowired
    AdminMapper adminMapper;
    @Override
    public Admin selectAdmin(String id) {
        return adminMapper.selectAdmin(id);
    }
}
