package com.zlt.boot.key;

import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;

@Configuration
public class KeyGenerator implements org.springframework.cache.interceptor.KeyGenerator {
    @Override
    public Object generate(Object o, Method method, Object... objects) {
        System.out.println(objects[0]);
        return new StringBuffer().append("user:uid:").append(objects[0]);


    }
}
