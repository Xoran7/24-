package com.zlt.boot.controller;

import com.zlt.boot.entity.User;
import com.zlt.boot.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.thymeleaf.ThymeleafProperties;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class UserController {
//  Logger logger = LoggerFactory.getLogger(getClass());
  @Autowired
  private UserService userService;
  @GetMapping("hello")
  public String hello(){
//    logger.info("方法进来了");
//    log.info("方法进来了");
    log.trace("trace日志");
    log.debug("debug日志");
    //默认是info级别
    log.info("info日志");
    log.warn("warn日志");
    log.error("error日志");
    return "hello world";
  }
  @GetMapping("userInfo")

    public User userInfo(Long id){
    User user = userService.userInfo(id);
    return user ;
  }
}
