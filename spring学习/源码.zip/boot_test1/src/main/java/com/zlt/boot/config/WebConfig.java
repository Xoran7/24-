package com.zlt.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
@Configuration
public class WebConfig implements WebMvcConfigurer {

    public void addCorsMappings(CorsRegistry registry){
        registry.addMapping("/**")
                .allowCredentials(true)//是否携带cookie
                .allowedHeaders("*")//允许的请求头
                .exposedHeaders("*")//允许的响应头
                .allowedMethods("GET","POST")//允许的请求方式
                .allowedOrigins("*");//允许的源
    }
}
