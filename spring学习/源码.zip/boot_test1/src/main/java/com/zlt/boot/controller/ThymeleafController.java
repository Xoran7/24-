package com.zlt.boot.controller;


import com.zlt.boot.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class ThymeleafController {
    @GetMapping("test")
    public String test(Model model){
        //将对象放入Model  将数据放入请求作用域
        model.addAttribute("user",new User(1L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        List<User>users = new ArrayList<>();
        users.add(new User(1L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        users.add(new User(2L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        users.add(new User(3L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        users.add(new User(4L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        users.add(new User(5L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        users.add(new User(6L,18,"<b>seng</b>","帅气的森","123456",new Date()));
        model.addAttribute("users",users);
        return "test";
    }
}
