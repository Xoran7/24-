package com.zlt;

import org.apache.ibatis.io.Resources;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.exception.InvalidConfigurationException;
import org.mybatis.generator.exception.XMLParserException;
import org.mybatis.generator.internal.DefaultShellCallback;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        List<String> list = new ArrayList<>();
        //创建配置解析对象
        ConfigurationParser configurationParser = new ConfigurationParser(list);
        //解析并获取配置对象
        try {
            Configuration configuration = configurationParser.parseConfiguration(Resources.getResourceAsReader("generatorConfig.xml"));
            //创建生成器对象
            MyBatisGenerator myBatisGenerator = new MyBatisGenerator(configuration,new DefaultShellCallback(true),list);
            //执行生成
            myBatisGenerator.generate(null);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XMLParserException e) {
            e.printStackTrace();
        } catch (InvalidConfigurationException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
