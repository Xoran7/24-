package com.zlt;

import static org.junit.Assert.assertTrue;

import com.zlt.entity.User;
import com.zlt.entity.UserExample;
import com.zlt.mapper.UserMapper;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    private SqlSession sqlSession = null;

    @Before
    public void before(){
        //构建mybatis的环境
        InputStream resourceAsStream = AppTest.class.getClassLoader().getResourceAsStream("config.xml");
        //构建会话工厂  可以理解为一个数据源
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
        //得到会话  增删改不会自动提交事务，
        sqlSession = sqlSessionFactory.openSession();

    }
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        UserExample userExample = new UserExample();
        UserExample.Criteria criteria = userExample.createCriteria();
        criteria.andUserPhoneBetween("1","99999999999999999999999");
        List<User> users = userMapper.selectByExample(userExample);
        System.out.println(users);
    }
}
