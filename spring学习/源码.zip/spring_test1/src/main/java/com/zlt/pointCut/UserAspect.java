package com.zlt.pointCut;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
@Aspect//标记当前为切面类

public class UserAspect {
    @Pointcut("execution(public com.zlt.entity.User com.zlt.service.impl.UserServiceImpl.login(java.lang.String,java.lang.String))")
    public void login() {

    }

    /**
     * 标记什么时候在哪里执行
     *
     * @param joinPoint 切入的点
     */
    @Before("login()")
    public void before(JoinPoint joinPoint) {
        System.out.println("before执行");
        Object[] args = joinPoint.getArgs();
        System.out.println("参数为" + Arrays.toString(args));
        //getDeclaringTypeName类的名字 getName 方法的名字
        System.out.println("拦截的方法为:" + joinPoint.getSignature().getDeclaringTypeName() + joinPoint.getSignature().getName());
        System.out.println("拦截的位置：" + joinPoint.getStaticPart());
        System.out.println("拦截的目标对象" + joinPoint.getTarget());
    }

    /**
     * 相当于final
     *
     * @param joinPoint 切入的点
     */
//    @After("execution(public com.zlt.entity.User com.zlt.service.impl.UserServiceImpl.login(java.lang.String,java.lang.String))")
    public void After(JoinPoint joinPoint) {
        System.out.println("After执行");
        Object[] args = joinPoint.getArgs();
        System.out.println("参数为" + Arrays.toString(args));
        //getDeclaringTypeName类的名字 getName 方法的名字
        System.out.println("拦截的方法为:" + joinPoint.getSignature().getDeclaringTypeName() + joinPoint.getSignature().getName());
        System.out.println("拦截的位置：" + joinPoint.getStaticPart());
        System.out.println("拦截的目标对象" + joinPoint.getTarget());
    }

    /**
     * 正常执行的代码
     *
     * @param joinPoint
     */
//    @AfterReturning("execution(public com.zlt.entity.User com.zlt.service.impl.UserServiceImpl.login(java.lang.String,java.lang.String))")
    public void AfterReturning(JoinPoint joinPoint) {
        System.out.println("AfterReturning执行");
        Object[] args = joinPoint.getArgs();
        System.out.println("参数为" + Arrays.toString(args));
        //getDeclaringTypeName类的名字 getName 方法的名字
        System.out.println("拦截的方法为:" + joinPoint.getSignature().getDeclaringTypeName() + joinPoint.getSignature().getName());
        System.out.println("拦截的位置：" + joinPoint.getStaticPart());
        System.out.println("拦截的目标对象" + joinPoint.getTarget());
    }

    /**
     * 异常的时候执行
     *
     * @param joinPoint
     */
//    @AfterThrowing("execution(public com.zlt.entity.User com.zlt.service.impl.UserServiceImpl.login(java.lang.String,java.lang.String))")
    public void AfterThrowing(JoinPoint joinPoint) {
        System.out.println("AfterThrowing执行");
        Object[] args = joinPoint.getArgs();
        System.out.println("参数为" + Arrays.toString(args));
        //getDeclaringTypeName类的名字 getName 方法的名字
        System.out.println("拦截的方法为:" + joinPoint.getSignature().getDeclaringTypeName() + joinPoint.getSignature().getName());
        System.out.println("拦截的位置：" + joinPoint.getStaticPart());
        System.out.println("拦截的目标对象" + joinPoint.getTarget());
    }

    /**
     * 环绕执行
     */
//    @Around(value = "execution(public com.zlt.entity.User com.zlt.service.impl.UserServiceImpl.login(java.lang.String,java.lang.String))")
    public Object around(ProceedingJoinPoint pjb) throws Throwable {
        System.out.println("around方法执行");
        Object proceed = pjb.proceed();//目标方法正常执行
        System.out.println("around方法之后");
        return proceed;

    }

}
