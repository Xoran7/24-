package com.zlt.service.impl;

import com.zlt.entity.User;
import com.zlt.mapper.UserMapper;
import com.zlt.mapper.impl.UserMapperImpl;
import com.zlt.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service//标记当前为业务层，并且放在spring容器中
//@Component
public class UserServiceImpl implements UserService {

//    UserMapper userMapper = new UserMapperImpl();
    //@Resource(name = "userServiceImpl")指定容器中的id进行注入
    //根据类型去找

    //    //指定名称
//    @Qualifier("UserMapperImpl")
    @Autowired
    private UserMapper userMapper;

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public User login(String userName, String password) {
        System.out.println("UserService执行");
        User user = userMapper.selectUser(userName, password);
//        System.out.println(1/0);

        return user;

    }
}
