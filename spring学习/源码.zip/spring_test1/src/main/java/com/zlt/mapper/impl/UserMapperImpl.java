package com.zlt.mapper.impl;

import com.zlt.entity.User;
import com.zlt.mapper.UserMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository//标记当前类为dao层，然后放入到spring容器中
//@Component//这个是直接放入spring容器中 value就是放入容器中的id 如果不写就是默认是类名首字母小写

public class UserMapperImpl implements UserMapper {
    @Override
    public User selectUser(String userName, String password) {
        System.out.println("userMapper执行");

        return new User(userName, password);
    }
}
