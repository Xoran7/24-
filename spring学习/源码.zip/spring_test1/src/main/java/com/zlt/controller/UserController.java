package com.zlt.controller;

import com.zlt.entity.User;
import com.zlt.service.UserService;
import com.zlt.service.impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

@Controller//标记当前类为控制层，并且放入spring容器中，起到标记的作用
@Component
public class UserController {
//    UserService userService = new UserServiceImpl();

    private String name;
    private Integer age;

    //    public UserController( UserService userService,String name, Integer age) {
//        System.out.println("name==="+name+"age==="+age);
//        this.userService = userService;
//        this.name = name;
//        this.age = age;
//
//    }
    private Set set;

    public void setSet(Set set) {
        this.set = set;
    }

    private List list;


    public void setList(List list) {
        this.list = list;
    }

    public Map map;

    public void setMap(Map map) {
        this.map = map;
    }

    @Autowired
    private UserService userService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    private Object[] arr;

    public void setArr(Object[] arr) {
        this.arr = arr;
    }

    private Properties properties;

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public User login(String userName, String password) {
//        System.out.println(arr.getClass());
//        System.out.println(map.getClass());
//        System.out.println(set.getClass());
//        System.out.println(list.getClass());
        System.out.println("controller执行");

        return userService.login(userName, password);
    }
}
