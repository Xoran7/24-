package com.zlt.mapper;

import com.zlt.entity.User;

public interface UserMapper {
    User selectUser(String userName, String password);
}
