package com.zlt;

import static org.junit.Assert.assertTrue;

import com.zlt.controller.UserController;
import com.zlt.entity.User;
import org.junit.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
//        UserController userController = new UserController();
//        User user = userController.login("王家僧", "123456");
//        System.out.println(user);
        //创建容器对象
        BeanFactory beanFactory = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        //从容器中获取了对象
        UserController userController = beanFactory.getBean("userController", UserController.class);
        //执行方法
        User user = userController.login("zhangsan", "123456");
        System.out.println(user);

    }
}
